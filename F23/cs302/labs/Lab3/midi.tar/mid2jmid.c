#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "midi.h"

int main()
{
  char s[1000];
  int i, format, ntracks, division, tracklength, dtime, event, metatype,
         nbytes, ntoread, base, note, velocity, track;
  
  if (fread(s, 1, 4, stdin) != 4) { fprintf(stderr, "No header\n"); exit(1); }
  s[4] = '\0';
  if (strcmp("MThd", s) != 0) { fprintf(stderr, "Bad header\n"); exit(1); }

  i = readint();

  format = readshort();
  ntracks = readshort();
  division = readshort();

  printf("JMID FILE\n");
  printf("Format: %d  ntracks: %d  Division: %d\n", 
    format, ntracks, division);

  if (i < 6) { fprintf(stderr, "header size too small\n"); exit(1); }
  if (i > 6) { fseek(stdin, i-6, 1); }

  for (track = 0; track < ntracks; track++) {
    printf("TRACK %d\n", track);
    if (fread(s, 1, 4, stdin) != 4) { fprintf(stderr, "No track\n"); exit(1); }
    s[4] = '\0';
    if (strcmp("MTrk", s) != 0) { fprintf(stderr, "Bad track\n"); exit(1); }
    tracklength = readint();

    base = ftell(stdin);
    /* read events */
    while (ftell(stdin) < base + tracklength) {
      dtime = readvarlen();
      event = getchar();
      printf("%7d ", dtime);
      if (event < 0xf0) {

        /* read midi events */

        if (event >= 0x80 && event <= 0x8f) {
          note = getchar();
          velocity = getchar();
          printf("NOTE-OFF %02X %3d %3d\n", event , note, velocity);
        } else if (event >= 0x90 && event <= 0x9f) {
          note = getchar();
          velocity = getchar();
          printf("NOTE-ON  %02X %3d %3d\n", event , note, velocity);
        } else if (event >= 0xa0 && event <= 0xaf) {
          note = getchar();
          velocity = getchar();
          printf("PRESSUR  %02X %3d %3d\n", event , note, velocity);
        } else if (event >= 0xb0 && event <= 0xbf) {
          note = getchar();
          velocity = getchar();
          printf("CONTROL  %02X %3d %3d\n", event , note, velocity);
        } else if (event >= 0xc0 && event <= 0xcf) {
          note = getchar();
          printf("PROGRM   %02X %3d\n", event , note);
        } else if (event >= 0xd0 && event <= 0xdf) {
          note = getchar();
          printf("CHANPRE  %02X %3d\n", event , note);
        } else if (event >= 0xe0 && event <= 0xef) {
          note = getchar();
          velocity = getchar();
          printf("PWHEEL   %02X %3d %3d\n", event , note, velocity);
        } else {
          velocity = getchar();
          printf("RSTAT       %3d %3d\n", event , velocity);
        }
      } else if (event == 0xf0 || event == 0xf7) {
        nbytes = readvarlen();
        printf("SYSEX      %02X %d", event, nbytes);
        for (i = 0; i < nbytes; i++) { 
          if (i != 0 && i % 10 == 0) printf("\n                   ");
          printf(" %02X", getchar());
        }
        printf("\n");
      } else if (event == 0xff) {
        metatype = getchar();
        nbytes = readvarlen();
        printf("META       %02X %02X %d", event, metatype, nbytes);
        for (i = 0; i < nbytes; i++) { 
          if (i != 0 && i % 10 == 0) printf("\n                   ");
          printf(" %02X", getchar());
        }
        printf("\n");
      }
    }
  }
  return 0;
}
